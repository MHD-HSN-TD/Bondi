var brands = document.getElementsByClassName("fa-brands");
console.log(brands);